import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from model.utils.net_utils import grad_reverse
from torch.autograd import Variable

def calc_mean_std(features):
    """
    :param features: shape of features -> [batch_size, c, h, w]
    :return: features_mean, feature_s: shape of mean/std ->[batch_size, c, 1, 1]
    """

    batch_size, c = features.size()[:2]
    features_mean = features.reshape(batch_size, c, -1).mean(dim=2).reshape(batch_size, c, 1, 1)
    features_std = features.reshape(batch_size, c, -1).std(dim=2).reshape(batch_size, c, 1, 1) + 1e-6
    return features_mean, features_std


def content(x):
    features_mean, features_std = calc_mean_std(x)
    out = (x - features_mean) / features_std
    return out



class afsp(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(afsp, self).__init__()
        self.inplanes = in_planes
        self.fc = nn.Sequential(nn.Conv2d(in_planes*2, in_planes // 16, 1, bias=False),
                                nn.ReLU(),
                                nn.Conv2d(in_planes // 16, in_planes*2, 1, bias=False))

    def forward(self, x,alpha=0.5,use_grl=True):
        if use_grl:
            x = grad_reverse(x, lambd=1.0)
        norm_ori = torch.norm(x,p=1)

        features_mean, features_std = calc_mean_std(x)
        input = torch.cat((features_mean,features_std),dim=1)
        out = self.fc(input)
        style_mean = out[:,:self.inplanes,:,:]*alpha + features_mean*(1.0-alpha)
        style_std = out[:,self.inplanes:,:,:]*alpha + features_std*(1.0-alpha)
        normalized_features = style_std * (x - features_mean) / features_std + style_mean
        new_norm = torch.norm(normalized_features,p=1) + 1e-8
        rescale_normalized_features = normalized_features / new_norm * norm_ori
        if use_grl:
            rescale_normalized_features = grad_reverse(rescale_normalized_features, lambd=1.0)
        return rescale_normalized_features



